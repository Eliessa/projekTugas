from operator import index
from turtle import title
from django.contrib import admin
from django.shortcuts import render
from django.urls import path, include
from django.http import HttpResponse
from django.conf import settings
from django.conf.urls.static import static
from dashboard.views import tambah_barang, Barang_view,trsn, ItemsView, ItemView
from dashboard.views import *

def coba1(request):
    return HttpResponse('Selamat Sore, selamat menangis')
def  coba2(request):
    titelnya="Home"
    konteks = {
        'titel':titelnya,
    }
    return render(request,'index.html', konteks)

urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('', index, name = 'home'),
    path ('items/', ItemsView),
    path('item/<int:nm>/', ItemView),
    path('addbarang/', tambah_barang),
    path('Vbrg/',Barang_view, name = 'barang_uts'),
    path('vtrans/',trsn, name = 'trsn_uts'),
    path('addtransaksi/', tambah_transaksi),
    path('ubahA/<int:id_transaksi>',ubah_trsn, name='ubah_trsn'),
    path('hapusT/<int:id_transaksi>',hapus_trsn, name = 'hapus_trsn'),
    path('ubah/<int:id_barang>',ubah_brg, name = 'ubah_brg'),
    path('hapus/<int:id_barang>',hapus_brg, name = 'hapus_brg'),
]
