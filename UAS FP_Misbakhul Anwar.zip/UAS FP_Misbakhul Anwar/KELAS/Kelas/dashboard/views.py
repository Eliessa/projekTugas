from email import message
from tkinter.tix import Form
from urllib.request import Request
from django.shortcuts import redirect, render
from django.test import TransactionTestCase
from dashboard.forms import FormBarang, FormTransaksi
from dashboard.models import Barang, Transaksi, ItemModel
from rest_framework.parsers import JSONParser
from django.http import Http404, HttpResponse,JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .serializers import ItemSerializer
from django.contrib import messages


@csrf_exempt
def ItemsView(request):
 
    if request.method == 'GET':
        items = ItemModel.objects.all()
        serializer = ItemSerializer(items, many =True)
        return JsonResponse(serializer.data, safe =False)
 
    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer =ItemSerializer(data = data)
 
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data,status =201)
        return JsonResponse(serializer.errors,status = 400)

@csrf_exempt
def ItemView(request,nm):
    try: 
        item = ItemModel.objects.get(id = nm)
    except ItemModel.DoesNotExist:
        raise Http404('Not found')
 
    if request.method == 'GET':
        serializer = ItemSerializer(item)
        return JsonResponse(serializer.data)
 
    if request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = ItemSerializer(item,data =data)
 
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status =400)
 
    if request.method == "DELETE":
        item.delete()
        return HttpResponse(status =204)



def tambah_barang(request):
    if request.POST:
        form= FormBarang(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "data done")
            form = FormBarang()
            konteks = {
                'form':form,
            }
            return render(request, 'tambah_barang.html', konteks)
    else:
        form=FormBarang()
        konteks = {
                'form':form,
            }
        return render(request, 'tambah_barang.html', konteks)

#

#
def Barang_view(request):
    barangs=Barang.objects.all()
    konteks={
        'barangs':barangs  
    }
    return render(request,'tampil_brg.html',konteks)
#
def trsn(request):
    trs=Transaksi.objects.all()
    konteks={
        'trs':trs
    }
    return render(request,'tampil_transaksi.html',konteks)
#
def ubah_brg(request, id_barang):
    barangs=Barang.objects.get(id=id_barang)
    if request.POST:
        form=FormBarang(request.POST, instance=barangs)
        if form.is_valid():
            form.save()
            messages.success(request, "data done")
            return redirect('ubah_brg', id_barang=id_barang)
    else:
        form=FormBarang(instance=barangs)
        konteks = {
            'form':form,
            'barangs':barangs
        }
    return render(request, 'ubah_brg.html', konteks)
#
def hapus_brg(request, id_barang):
    barangs=Barang.objects.filter(id=id_barang)
    barangs.delete()
    messages.success(request,"data deleted")
    return redirect('barang_uts')
def index(request):
    return render(request,'index.html')

#TRANSAKSI
def tambah_transaksi(request):
    if request.POST:
        form = FormTransaksi(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "data berhasil di add")
            form = FormTransaksi()
            konteks = {
                'form':form,
            }
            return render(request, 'tambah_transaksi.html', konteks)
    else:
        form=FormTransaksi()
        konteks = {
            'form':form,
        }
        return render(request, 'tambah_transaksi.html', konteks)
    
def ubah_trsn(request, id_transaksi):
    trs=Transaksi.objects.get(id=id_transaksi)
    if request.POST:
        form=FormTransaksi(request.POST, instance=trs)
        if form.is_valid():
            form.save()
            messages.success(request, "data done di ubah")
            return redirect('ubah_trsn', id_transaksi=id_transaksi)
    else:
        form=FormTransaksi(instance=trs)
        konteks = {
            'form':form,
            'trs':trs
        }
    return render(request,'tampil_T.html',konteks)


def hapus_trsn(request, id_transaksi):
    transaksi=Transaksi.objects.filter(id=id_transaksi)
    transaksi.delete()
    messages.success(request,"data deleted")
    return redirect('trsn_uts')
def index(request):
    return render(request,'index.html')

